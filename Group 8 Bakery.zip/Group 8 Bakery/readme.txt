Member
Email : sem3sbakery2025@gmail.com
Password : 123456

Admin:
Email   : admin@gmail.com
Password : 123456


For testing payment confirmation function please using the real email or:

Demo email : sem3sbakery2025@gmail.com
Password : DFT1S3G82025!